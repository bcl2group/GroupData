#ifndef NETWORK_H
#define NETWORK_H

#include <string>
#include <iostream>
#include <vector>

using namespace std;

class Network
{
public:

	Network();
	Network(int numOfNodes, vector<int> genome, vector< vector<int> > dataset);
	void setGenome(vector<int>genome);
	vector<int> getGenome();
	vector<int> getParents(int i);
	void print();
	
private:
	
	vector<int> genome;
	vector< vector<int> > parents;
	int numOfNodes;
	vector< vector<int> > dataset;
	
};

#endif

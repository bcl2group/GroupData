#ifndef NODEPAIR_H
#define NODEPAIR_H

#include <vector>
#include <vecmath.h>

struct Nodepair
{
	float maxScore;
	int maxNode;
};

#endif

using namespace std;

Node::Node(String n)
{
	String name = n;
}

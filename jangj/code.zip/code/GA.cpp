#include "GA.h"
#include <cstdlib>

using namespace std;

GA::GA(int numOfNodes, vector< vector<int> > dataset, int maxParents):K2(numOfNodes, dataset, maxParents)
{
	this->numOfNodes = numOfNodes;
	this->dataset = dataset;
	this->maxParents = maxParents;
	this->size = pow(numOfNodes,2);
	
	Network n1;
	Network n2;
	vector<Network> n = this->makePopulation(5, n1, n2);		// create 5 individuals
	this->networks = n;
	
	this->topNetwork = n1;
	this->nextTopNetwork = n2;
	this->topScore = -1.0f;
	this->nextTopScore = -1.0f;
	
	for (int depth = 1; depth <= 10; depth++)
	{
		cout << "Round " << depth << endl;
		this->mate(topNetwork, nextTopNetwork);
	}
	
	vector<int> topGenes = topNetwork.getGenome();
	
	cout << "Genetic algorithm result:" << endl;
	for (int l = 0; l < numOfNodes; l++)
	{
		for (int k = 0; k < numOfNodes; k++)
		{
			if (topGenes[l*numOfNodes + k] == 1)
			{
				cout << "Node: X_" << k << ", Parent: X_" << l << endl;
			}
		}
	}

}

vector<Network> GA::makePopulation(int numOfInds, Network& n1, Network& n2)
{
	vector<Network> n;
	
	for (int num = 0; num < numOfInds; num ++)
	{
		vector<int> genome;
		
		for (int i = 0; i < numOfNodes; i++)
		{
			
			for (int j = 0; j < numOfNodes; j++)
			{
				int random = rand()%2;
				genome.push_back(random);
			}
			
		}
		
		Network network = Network(numOfNodes, genome, dataset);
		vector<int> g = network.getGenome();
		dagify(g);
		network.setGenome(g);
		n.push_back(network);
	
	}
	
	/**
	// print network genomes
	for (unsigned k = 0; k < n.size(); k++)
	{
		n[k].print();
	}
	*/
	
	float highScore = -1.0f;
	Network highNet;
	Network secondHighNet;
	float secondHighScore = -1.0f;
	float score;
	
	for (unsigned nets = 0; nets < n.size(); nets++)
	{
		Network network = n[nets];
		score = this->scoreNetwork(network);
		if (score > highScore)
		{
			secondHighScore = highScore;
			secondHighNet = highNet;
			highScore = score;
			highNet = network;
		}
		else if (score < highScore && score > secondHighScore)
		{
			secondHighScore = score;
			secondHighNet = network;
		}
	}
	
	n1 = highNet;
	n2 = secondHighNet;
	
	/**
	// print two highest-scoring genomes
	cerr << "The highest-scoring genome is " n1.print() << " with score " << highScore << endl;
	cerr << "The highest-scoring genome is " n2.print() << " with score " << secondHighScore << endl;
	*/
	
	return n;
}

float GA::scoreNetwork(Network n)
{
	float totalScore = 0.0f;
	
	for (int i = 0; i < numOfNodes; i++)
	{
		// super K2 scoring function
		totalScore += this->scoringFunction(i, n.getParents(i), dataset, numOfNodes);
	}
	
	return totalScore;
}

void GA::mate(Network n1, Network n2)
{
	//n1.print();
	//n2.print();
	
	long max = RAND_MAX;
	float random = (float) rand()/ (max+1);	// random number from [0,1]
	
	int index = int(random*size);
	vector<int> n1genome = n1.getGenome();
	vector<int> n2genome = n2.getGenome();
	
	vector<int> n1Head = std::vector<int>(n1genome.begin(), n1genome.begin() + index);
	vector<int> n1Tail = std::vector<int>(n1genome.begin() + index, n1genome.end());
	
	vector<int> n2Head = std::vector<int>(n2genome.begin(), n2genome.begin() + index );
	vector<int> n2Tail = std::vector<int>(n2genome.begin()+ index, n2genome.end());
	
	n1Head.insert(n1Head.end(), n2Tail.begin(), n2Tail.end());
	n2Head.insert(n2Head.end(), n1Tail.begin(), n1Tail.end());

	mutate(n1Head);
	mutate(n2Head);
	
	dagify(n1Head);
	dagify(n2Head);
	
	Network n3 = Network(numOfNodes, n1Head, dataset);
	Network n4 = Network(numOfNodes, n2Head, dataset);
	
	networks.push_back(n3);
	networks.push_back(n4);
	
	while (networks.size() > 10)
	{
		networks.erase(networks.begin());
	}
	
	float n3score = this->scoreNetwork(n3);
	float n4score = this->scoreNetwork(n4);
	
	//n3.print();
	//n4.print();
	
	if (n3score > topScore)
	{
		cerr << "Top Node changed: ";
		n3.print();
		nextTopScore = topScore;
		nextTopNetwork = topNetwork;
		topScore = n3score;
		topNetwork = n3;
	}	
	else if (n3score > nextTopScore)
	{
		nextTopScore = n3score;
		nextTopNetwork = n3;
	}
	
	if (n4score > topScore)
	{
		cerr << "Top Node changed: ";
		n4.print();
		nextTopScore = topScore;
		nextTopNetwork = topNetwork;
		topScore = n4score;
		topNetwork = n4;
	}
	else if (n4score > nextTopScore)
	{
		nextTopScore = n4score;
		nextTopNetwork = n4;
	}
	
}

void GA::mutate(vector<int> &genome)
{
	/**
	cout << "Before mutation: ";
	
	for (unsigned j = 0; j < genome.size(); j++)
	{
		cerr << genome[j];
	}
	cerr << " " << endl;
	*/
	
	long max = RAND_MAX;
	
	float random1 = (float) rand()/ (max+1);	// random number from [0,1)
	int mutations = int(random1*size*0.2);
	int random2;
	
	for (int i = 0; i < mutations; i++)
	{
		random2 = rand()%size;
		genome[random2] = abs(genome[random2]-1);
	}
	
	/**
	cout << "After mutation: ";
	
	for (unsigned k = 0; k < genome.size(); k++)
	{
		cerr << genome[k];
	}
	cerr << " " << endl;
	cerr << " " << endl;
	*/
}

void GA::dagify(vector<int> &genome)
{
	for (int i = 0; i < numOfNodes; i++)
	{
		for (int j = 0; j < numOfNodes; j++)
		{	
			// A node can't be its own parent
			if (i==j)
			{
				genome[i*numOfNodes + j] = 0;
			}
				
		}
	}
	
        vector<int> visited;
        int start;
        int search;
        
        bool y;
        
        /**
        // print statements
        cerr << "deleting self edges:     ";
        
	for (unsigned a = 0; a < genome.size(); a ++)
	{
		cerr << genome[a];
	}
	cerr << " "<<endl;
	*/
	
        for (int j = 0; j < numOfNodes; j++)
        {
        	start = j;
        	search = j;
        	y = true;
        	visited.clear();
        	
		while (y)
		{
			y = depthFirstSearch(start, search, numOfNodes, genome, visited);
		}
	}
	
	/**
	// print statements
        cerr << "breaking cycles:         ";
	
	for (unsigned a = 0; a < genome.size(); a ++)
	{
		cerr << genome[a];
	}
	cerr << " "<<endl;
	*/
	
	for (int k = 0; k < numOfNodes; k++)
	{
		int total = 0;
		
		for (int m = 0; m < numOfNodes; m++)
		{
			total += genome[k*numOfNodes + m];
		}
		
		vector<int> isNeighbors;
		
		for (int l = 0; l < numOfNodes; l++)
		{
			if (genome[l*numOfNodes + k] == 1)
			{
				isNeighbors.push_back(l);
			}
			
		}
		if (total == 0 && isNeighbors.size() == 0)
		{
			int forcedParent = (k+1)%numOfNodes;
			genome[forcedParent*numOfNodes + k] = 1;
		}
	}
	
	/**
	// print statements
        cerr << "connecting stray nodes:  ";
	
	for (unsigned a = 0; a < genome.size(); a ++)
	{
		cerr << genome[a];
	}
	cerr << " "<<endl;
	cerr << " "<<endl;
	*/
			
}

bool GA::depthFirstSearch(int start, int search, int numOfNodes, vector<int>& dag, vector<int>& visited)
{
	vector<bool> vectorBooleans;
	if (dag[start*numOfNodes + search] == 1)
	{
		dag[start*numOfNodes + search] = 0;
		return true;
	}
	
	for (int i = 0; i < numOfNodes; i++)
	{
		int dag_position = i + start*numOfNodes;
		
		if (dag[dag_position] == 1)
		{
			
			bool hasBeenVisited = false;
			for (unsigned d = 0; d < visited.size(); d++)
			{
				if (visited[d] == i)
				{
					hasBeenVisited = true;
				}
			}
			
			if (hasBeenVisited)
			{
				break;
			}
			
			visited.push_back(i);
			vectorBooleans.push_back(depthFirstSearch(i, search, numOfNodes, dag, visited));
		}
	}
	
	for (unsigned j = 0; j < vectorBooleans.size(); j++)
	{
		if (vectorBooleans[j] == true)
		{
			return true;
		}
	}
	
	return false;
}
	
vector<int> GA::getGenome(int i)
{
	if (i >= (int) networks.size())
	{
		vector<int> empty;
		return empty;
	}
	
	return networks[i].getGenome();
}	
	
bool GA::elementof(int i, vector<int> v)
{
	for (unsigned index = 0; index < v.size(); index++)
	{
		if (v[index] == i)
		{
			return true;
		}
	}
	
	return false;
}

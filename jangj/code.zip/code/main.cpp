#include "K2.h"
#include "GA.h"
#include <iostream>
#include <math.h>

using namespace std;

// Globals here.
namespace
{
        void add3Vector(int i, int j, int k, vector< vector<int> >& set)
        {
                vector<int> a;
                a.push_back(i);
                a.push_back(j);
                a.push_back(k);

                set.push_back(a);
        }
        
}

int main(  )
{
        vector< vector<int> > dataset;
        add3Vector(1, 0, 0, dataset);
        add3Vector(1, 1, 1, dataset);
        add3Vector(0, 0, 1, dataset);
        add3Vector(1, 1, 1, dataset);
        add3Vector(0, 0, 0, dataset);
        add3Vector(0, 1, 1, dataset);
        add3Vector(1, 1, 1, dataset);
        add3Vector(0, 0, 0, dataset);
        add3Vector(1, 1, 1, dataset);
        add3Vector(0, 0, 0, dataset);
        K2 k2 = K2(3, dataset, 2);
        GA ga = GA(3, dataset, 1);
        
        k2.findParents();
        
        return 0;
}


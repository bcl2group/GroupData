#ifndef GA_H
#define GA_H

#include "Nodepair.h"
#include "K2.h"
#include "Network.h"
#include <vector>
#include <string>
#include <iostream>
#include <math.h>

using namespace std;

class GA: public K2
{
public:

	GA(int numOfNodes, vector< vector<int> > dataset, int maxParents);
	float scoreNetwork(Network n);
	vector<Network> makePopulation(int numOfInds, Network& n1, Network& n2);
	void mate(Network n1, Network n2);
	void mutate(vector<int> &genome);
	vector<int> getGenome(int i);
	
private:
	
	void dagify(vector<int> &genome);
	bool depthFirstSearch(int start, int search, int numOfNodes, vector<int>& dag, vector<int>& visited);
	bool elementof(int i, vector<int> v);
	int size;
	vector<Network> networks;
	Network topNetwork;
	Network nextTopNetwork;
	float topScore;
	float nextTopScore;
	
};

#endif

#include "Network.h"

using namespace std;

Network::Network()
{
}

Network::Network(int numOfNodes, vector<int> genome, vector< vector<int> > dataset)
{
	this->numOfNodes = numOfNodes;
	this->genome = genome;
	this->dataset = dataset;
	vector< vector<int> > parents;
	
	int position = 0;
	
	for (unsigned j = 0; j < genome.size(); j+=numOfNodes)
	{
		vector<int> p;
		
		for (int i = 0; i < numOfNodes; i++)
		{
			if (genome[position + i] == 1)
			{
				p.push_back(i);
			}
		}
		
		parents.push_back(p);
		position ++;
	}
	
	this->parents = parents;
			
}

void Network::setGenome(vector<int> genome)
{
	this->genome = genome;
}

vector<int> Network::getGenome()
{
	return genome;
}

vector<int> Network::getParents(int i)
{
	return parents[i];
}

void Network::print()
{
	for (unsigned i = 0; i < genome.size()-1; i++)
	{
		cout << genome[i];
	}
	
	cout << genome[genome.size()-1] << endl;
}

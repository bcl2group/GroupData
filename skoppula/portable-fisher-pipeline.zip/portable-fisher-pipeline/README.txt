-------------------------------------------------------------------------------------
This document is a brief instruction on how to use the Pipeline to perform
enrichment using the Fisher test. This document references data that can be 
found in this directory [portable-pipeline]. Written by Skanda Koppula.

If you need clarification, notice any errors, or encounter any problems, 
please feel free to contact Skanda (skoppula@andover.edu). Enjoy!
Last Revision: June 20, 2012
-------------------------------------------------------------------------------------
Everything is set up for a quick test of the Fisher test. It uses sample data sources 
(in directories described below), so you can run it via the Terminal command:
	
	nohup ./pipeline.run &

Output is given in the file nohup.out and the output folder. You can find some 
options sample input in the data folder (see below for more description)

By using nohup and &, all Terminal output is put into the file nohup.out and the
command is run the background. This means you will be able to close Terminal
and the program will continue to run. To stop the program, press Cntrl-C.
-------------------------------------------------------------------------------------

1. Set the appropriate values for properties.txt:

	a. Change train and trainFull to reference the your two [hopefully
		distinct] training data sets. They both must have a some file path assigned.
		Notice I set them in a folder called data so my variable assignments are as
		follows:
		
			train = ./data/coga-reduced-3.arff
			trainFull = ./data/coga-reduced-2.arff

	b. Choose which pathway libraries you want to use. I have a set of these pathway
		to gene mapping files in the folder pathway-libraries. In my example, I used
		the KEGG one:
		
			conceptToGenesList = C:/Users/Skanda/Desktop/pathway-libraries/c2.cp.kegg.v3.0.symbols.gmt	KEGG
	
	c. Change the variables snpToGenes and backgroundModel to
		be the directory of your WGAViewer SNP annotation output. For example, right now
		I have the variables set to reference a file [snp-annotations-small.csv] in a 
		folder called data. Both variables must be the same. You can assign these
		variables even if you select 'n' to isSNPData. I recommend assigning both 
		variables to a larger map, which maps more number of SNPs. You can email
		me asking for such a map (with >1,000,000 SNPs)
		
			snpToGenes = ./data/snp-annotations-large.csv
			backgroundModel = ./data/snp-annotations-large.csv

	d. Assign outputDir and savePValuesFileName to the folder you want created and
		your output saved in...I believe the reason why the output is empty for the
		sample data, is because the input train and trainFull data are both from the same
		source.
		
	e. Change numEnvVariables to be the number of environmental variables you have in
		your two data files.
		
	f. Increasing the variable 'iterations', increases the number of random classifiers
		in distributions created, which may increase significance of results. However,
		increasing iterations uses oodles of memory.
	
2. Change the appropriate file paths in pipeline.run

	a. Do NOT disturb the pathway_lib folder and you should be good to go. The first 
		six lines of pipeline.run should NOT be changed, unless you wish to relocate
		the location of these libraries...in which case just put the appropriate
		directories in place of /pipeline_lib/***.jar
		
	b. I suggest you change the following things to the last line of the file:
		
			i. Change the 1 in Xmx1g to the amount of RAM you want to allocate to
				this program.
			ii. You can add the -d64 or -d32 flag after 'java' if you are using 
				a 64-bit or 32-bit machine...but you don't have to.
			
	
You should be able to run it anywhere.
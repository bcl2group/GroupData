package main.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class FindSignificantConceptsTest {

	@Test
	public void testFdrStorey() {
	}

	@Test
	public void testNoCorrection() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testFdrBenjamini() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testBonferroni() {
		fail("Not yet implemented"); // TODO
	}

}

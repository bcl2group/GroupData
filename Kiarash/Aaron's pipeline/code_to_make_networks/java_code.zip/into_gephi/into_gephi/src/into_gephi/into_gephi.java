/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package into_gephi;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import org.gephi.data.attributes.api.AttributeColumn;
import org.gephi.data.attributes.api.AttributeController;
import org.gephi.data.attributes.api.AttributeModel;
import org.gephi.filters.api.FilterController;
import org.gephi.graph.api.DirectedGraph;
import org.gephi.graph.api.GraphController;
import org.gephi.graph.api.GraphModel;
import org.gephi.graph.api.Node;
import org.gephi.graph.api.UndirectedGraph;
import org.gephi.io.exporter.api.ExportController;
import org.gephi.io.exporter.spi.Exporter;
import org.gephi.io.importer.api.Container;
import org.gephi.io.importer.api.EdgeDefault;
import org.gephi.io.importer.api.ImportController;
import org.gephi.io.processor.plugin.DefaultProcessor;
import org.gephi.layout.plugin.forceAtlas2.ForceAtlas2;
import org.gephi.layout.plugin.forceAtlas2.ForceAtlas2Builder;
import org.gephi.preview.api.PreviewController;
import org.gephi.preview.api.PreviewModel;
import org.gephi.preview.api.PreviewProperty;
import org.gephi.preview.types.EdgeColor;
import org.gephi.project.api.ProjectController;
import org.gephi.project.api.Workspace;
import org.gephi.ranking.api.Ranking;
import org.gephi.ranking.api.RankingController;
import org.gephi.ranking.api.Transformer;
import org.gephi.ranking.plugin.transformer.AbstractColorTransformer;
import org.gephi.ranking.plugin.transformer.AbstractSizeTransformer;
import org.gephi.statistics.plugin.GraphDistance;
import org.openide.util.Exceptions;
import org.openide.util.Lookup;


/**
 *
 * @author Aaron
 */
public class into_gephi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        into_gephi g = new into_gephi();
        try{
          
            g.geff_away();
        
        
        } catch(Exception ex){
            System.out.println(ex.toString());
        }
        
    }
    
    
    public void geff_away() throws IOException{
       //Init a project - and therefore a workspace
        
        Boolean exporting = true;
        
        FileReader fstream = new FileReader("C:/users/aaron/desktop/reza_stuff_some_out_10/list.txt");
        BufferedReader listy = new BufferedReader(fstream);

        //Close the output stream
        

       String flef;
        
        while ((flef = listy.readLine()) != null){
            String file_name_in = flef.trim();
            int indexOfPeriod = flef.indexOf('.');
            String stub = flef.substring(0, indexOfPeriod);
            String flout_png = stub.concat(".svg");
            System.out.println(flout_png);
            

            StringBuilder sb = new StringBuilder();
        
        ProjectController pc = Lookup.getDefault().lookup(ProjectController.class);
        pc.newProject();
        Workspace workspace = pc.getCurrentWorkspace();

        //Get models and controllers for this new workspace - will be useful later
        AttributeModel attributeModel = Lookup.getDefault().lookup(AttributeController.class).getModel();
        GraphModel graphModel = Lookup.getDefault().lookup(GraphController.class).getModel();
        PreviewModel model = Lookup.getDefault().lookup(PreviewController.class).getModel();
        ImportController importController = Lookup.getDefault().lookup(ImportController.class);
        FilterController filterController = Lookup.getDefault().lookup(FilterController.class);
        RankingController rankingController = Lookup.getDefault().lookup(RankingController.class);
        
//        String file_name_in = "C:/users/aaron/desktop/item/ (".concat(String.valueOf(iii)).concat(").gml");
//        String file_name_out_png = "C:/users/aaron/desktop/graphs (".concat(String.valueOf(iii)).concat(").png");
//        String file_name_out_svg = "C:/users/aaron/desktop/item (".concat(String.valueOf(iii)).concat(").svg");
        
//        sb.append(file_name_out_svg).append(",");
        
        //Import file       
        Container container;
        try {
            File file = new File(file_name_in);
            container = importController.importFile(file);
            container.getLoader().setEdgeDefault(EdgeDefault.DIRECTED);   
        } catch (Exception ex) {
            ex.printStackTrace();
            return;
        }
        
        //Append imported data to GraphAPI
        importController.process(container, new DefaultProcessor(), workspace);
        
        //See if graph is well imported
        DirectedGraph graph = graphModel.getDirectedGraph();
//        System.out.println("Nodes: " + graph.getNodeCount());
        
        sb.append(graph.getNodeCount()).append(",");
        sb.append(graph.getEdgeCount()).append(",");
        
//        System.out.println("Edges: " + graph.getEdgeCount());
        
        
        //Run ForceAtlas2 for 100 passes - The layout always takes the current visible view
        ForceAtlas2 layout = new ForceAtlas2(new ForceAtlas2Builder());
        layout.setGraphModel(graphModel);
        layout.resetPropertiesValues();
        layout.setAdjustSizes(Boolean.TRUE);
        layout.setScalingRatio(1000.0);
        layout.setGravity(200.0);
        layout.initAlgo();
 
        int max = 10;
        if (exporting == true){
            max = 10000;
        }
        for (int i = 0; i < max && layout.canAlgo(); i++) {
            layout.goAlgo();
        }
        layout.endAlgo();
        
        //Preview
        model.getProperties().putValue(PreviewProperty.SHOW_NODE_LABELS, Boolean.TRUE);
        model.getProperties().putValue(PreviewProperty.NODE_LABEL_PROPORTIONAL_SIZE, Boolean.FALSE);
        model.getProperties().putValue(PreviewProperty.EDGE_COLOR, new EdgeColor(Color.DARK_GRAY));
        model.getProperties().putValue(PreviewProperty.EDGE_THICKNESS, new Float(0.9f));
        model.getProperties().putValue(PreviewProperty.EDGE_CURVED, Boolean.FALSE);
        model.getProperties().putValue(PreviewProperty.ARROW_SIZE, new Float (6.0f));


        
//        System.out.println(sb.toString());
//        out.append(sb.toString());
        
        //Export
        ExportController ec = Lookup.getDefault().lookup(ExportController.class);
        try {
            ec.exportFile(new File(flout_png));
        } catch (IOException ex) {
            ex.printStackTrace();
            return;
        }
//        try {
//            ec.exportFile(new File(file_name_out_svg));
//        } catch (IOException ex) {
//            ex.printStackTrace();
//            return;
//        }

        }
//        out.close();
    }
    
}


package javaapplication16;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
//import java.util.logging.Level;
//import java.util.logging.Logger;
import java.util.logging.Filter;
import java.util.logging.Level;
import java.util.logging.Logger;
import weka.attributeSelection.ChiSquaredAttributeEval;
import weka.attributeSelection.Ranker;
import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.bayes.BayesNet;
import weka.classifiers.bayes.net.estimate.SimpleEstimator;
import weka.classifiers.bayes.net.search.local.K2;
import weka.classifiers.bayes.net.search.local.TAN;
import weka.classifiers.rules.ZeroR;
import weka.core.Instances;
import weka.core.SelectedTag;
import weka.core.converters.ArffSaver;
import weka.filters.supervised.attribute.AttributeSelection;
import weka.filters.unsupervised.attribute.Discretize;
import weka.filters.unsupervised.attribute.NumericToNominal;
import weka.filters.unsupervised.attribute.RandomSubset;
import weka.filters.unsupervised.attribute.Remove;
import weka.filters.unsupervised.attribute.ReplaceMissingValues;


/**
 *
 * @author Aaron
 */
public class NewClass2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

            String[] surv = {"1,49,54,55,60","58","all","survdays_"};
            String[] rel = {"1,49,54,55,60,63","43","all","rel_"};
            String[] gvhd5 = {"1,49,54,55,60,63","6","all","gvhd5_"};
            String[] lfs = {"1,49,54,55,60,63","57","all","lfs_"};
            String[] d100 = {"1,54,55,60,63","48","all","d100_"};
            String[] d365 = {"1,49,55,60,63","52","all","d365_"};
            String[] dead = {"1,49,54,60,63","52","all","dead_"};
            

            do_stuff(surv);
            do_stuff(rel);
            do_stuff(gvhd5);
            do_stuff(lfs);
            do_stuff(d100);
            do_stuff(d365);
            do_stuff(dead);


    }

    private static void do_stuff(String[] args){

            String remStringStart = args[0];
            int outcome_int = Integer.valueOf(args[1]);
            String what_to_do = args[2];  //options: "save", "cross-validate", and "graph"
            String saver_file_stub = "C:/Users/Aaron/desktop/Reza_stuff_10/".concat(args[3]);
            String output_filename = "C:/Users/Aaron/desktop/Reza_stuff_10/".concat(args[3]).concat("results.txt");
            String alldata_filename = "c:/users/aaron/desktop/all_data.csv.arff";


        try{


        if (what_to_do.equals("cross-validate") || what_to_do.equals("all"))
            writeLineToFile("Outcome, ModelType, ROC, Accuracy\n", output_filename);

        }
        catch (Exception ex) {System.out.println(ex.toString());}


        Instances learnTop; try {
        learnTop = new Instances(new BufferedReader(new FileReader(alldata_filename))); learnTop.setClassIndex(learnTop.numAttributes() - 1);
        } catch (Exception ex) {System.out.println(ex.toString()); return; }

        System.out.println("okaydoke");

      // outcomes in index 47-64 - aka select only 1-46, 49, inverse selection





        Instances learn = new Instances(learnTop);
        learn.setClassIndex(0); // just making sure it's not one of the ones I want to Discretize
        Discretize d = new Discretize();
        d.setBins(2);
        d.setUseEqualFrequency(true);
        d.setAttributeIndices("47-64");
        try{
        d.setInputFormat(learn);
        learn = d.useFilter(learn,d);
        } catch (Exception ex) {System.out.println(ex.toString());}

        learn.setClassIndex(0); // just making sure it's not one of the ones I want to Discretize
        Discretize d2 = new Discretize();
        d2.setBins(3);
        d2.setUseEqualFrequency(false);
        d2.setAttributeIndices("1-46");
        try{
        d2.setInputFormat(learn);
        learn = d2.useFilter(learn,d2);
        } catch (Exception ex) {System.out.println(ex.toString());}

        learn.setClassIndex(0); // just making sure it's not one of the ones I want to Discretize
        ReplaceMissingValues rplm = new ReplaceMissingValues();
        rplm.setIgnoreClass(true);
        try{
        rplm.setInputFormat(learn);
        learn = rplm.useFilter(learn, rplm);
        } catch (Exception ex) {System.out.println(ex.toString());}


//        String remString = "1-10,20-46,".concat(String.valueOf(numLeave));  //donor
//        String remString = "1-32,42-46,".concat(String.valueOf(numLeave));  //recip



        Remove rmv = new Remove();
        rmv.setAttributeIndices(remStringStart.toString());
        rmv.setInvertSelection(false);


        try{
        rmv.setInputFormat(learn);
        learn = rmv.useFilter(learn, rmv);
        } catch (Exception ex) {System.out.println(ex.toString());}

        learn.setClassIndex(outcome_int-1);

        if ("save".equals(what_to_do) || "all".equals(what_to_do)){
            ArffSaver saver = new ArffSaver();
            saver.setInstances(learn);
            try {
                saver.setFile(new File(saver_file_stub.concat(String.valueOf(outcome_int)).concat(".arff")));
                System.out.println("Saved ARFF: ".concat(saver_file_stub).concat(String.valueOf(outcome_int)).concat(".arff"));
                saver.writeBatch();
            } catch (IOException ex) {
                Logger.getLogger(NewClass.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        BayesNet xK2 = new BayesNet();
        K2 zK2 = new K2();
        zK2.setInitAsNaiveBayes(false);
        zK2.setMaxNrOfParents(2);
        zK2.setRandomOrder(true);
        xK2.setSearchAlgorithm(zK2);

        BayesNet xTAN = new BayesNet();
        TAN zTAN = new TAN();
        xTAN.setSearchAlgorithm(zTAN);


        BayesNet xNaive = new BayesNet();
        K2 naive = new K2();
        naive.setInitAsNaiveBayes(true);
        naive.setMaxNrOfParents(1);
        xNaive.setSearchAlgorithm(naive);


        try {
        BayesNet cpyCls1 = (BayesNet) BayesNet.makeCopy(xK2);
        BayesNet cpyCls2 = (BayesNet) BayesNet.makeCopy(xK2);
        BayesNet cpyCls3 = (BayesNet) BayesNet.makeCopy(xK2);
        BayesNet cpyCls4 = (BayesNet) BayesNet.makeCopy(xK2);
        BayesNet cpyCls5 = (BayesNet) BayesNet.makeCopy(xK2);
        BayesNet cpyCls6 = (BayesNet) BayesNet.makeCopy(xTAN);
        BayesNet cpyCls7 = (BayesNet) BayesNet.makeCopy(xNaive);

        if (    "cross-validate".equals(what_to_do) || "all".equals(what_to_do)){
        
            System.out.println("Evaluating");
        Evaluation evalCV1 = new Evaluation(learn);
        Evaluation evalCV2 = new Evaluation(learn);
        Evaluation evalCV3 = new Evaluation(learn);
        Evaluation evalCV4 = new Evaluation(learn);
        Evaluation evalCV5 = new Evaluation(learn);
        Evaluation evalCV6 = new Evaluation(learn);
        Evaluation evalCV7 = new Evaluation(learn);

        Random rand = new Random(42);

        //CV overfit set
        System.out.println("CV-ing - 1");
        evalCV1.crossValidateModel(cpyCls1, learn, 10, rand);
        System.out.println("CV-ing - 2");
        evalCV2.crossValidateModel(cpyCls2, learn,10, rand);
        System.out.println("CV-ing - 3");
        evalCV3.crossValidateModel(cpyCls3, learn, 10, rand);
        System.out.println("CV-ing - 4");
        evalCV4.crossValidateModel(cpyCls4, learn,10, rand);
        System.out.println("CV-ing - 5");
        evalCV5.crossValidateModel(cpyCls5, learn,10, rand);
        System.out.println("CV-ing - 6");
        evalCV6.crossValidateModel(cpyCls6, learn,10, rand);
        System.out.println("CV-ing - 7");
        evalCV7.crossValidateModel(cpyCls7, learn,10, rand);


        StringBuilder line_to_write = new StringBuilder();

        line_to_write.append(String.valueOf(outcome_int)).append(",K2,").append(evalCV1.weightedAreaUnderROC()).append(",").append(evalCV1.pctCorrect()).append("\n");
        line_to_write.append(String.valueOf(outcome_int)).append(",K2,").append(evalCV2.weightedAreaUnderROC()).append(",").append(evalCV2.pctCorrect()).append("\n");
        line_to_write.append(String.valueOf(outcome_int)).append(",K2,").append(evalCV3.weightedAreaUnderROC()).append(",").append(evalCV3.pctCorrect()).append("\n");
        line_to_write.append(String.valueOf(outcome_int)).append(",K2,").append(evalCV4.weightedAreaUnderROC()).append(",").append(evalCV4.pctCorrect()).append("\n");
        line_to_write.append(String.valueOf(outcome_int)).append(",K2,").append(evalCV5.weightedAreaUnderROC()).append(",").append(evalCV5.pctCorrect()).append("\n");
        line_to_write.append(String.valueOf(outcome_int)).append(",TAN,").append(evalCV6.weightedAreaUnderROC()).append(",").append(evalCV6.pctCorrect()).append("\n");
        line_to_write.append(String.valueOf(outcome_int)).append(",Naive,").append(evalCV7.weightedAreaUnderROC()).append(",").append(evalCV7.pctCorrect()).append("\n");

        System.out.println(line_to_write);
        appendLineToFile(line_to_write.toString(), output_filename);
        }
        if ("graph".equals(what_to_do) || "all".equals(what_to_do)){
            System.out.println("graphing");
            make_graph(cpyCls1, learn, saver_file_stub, String.valueOf(outcome_int), 1);
            make_graph(cpyCls2, learn, saver_file_stub, String.valueOf(outcome_int), 2);
            make_graph(cpyCls3, learn, saver_file_stub, String.valueOf(outcome_int), 3);
            make_graph(cpyCls4, learn, saver_file_stub, String.valueOf(outcome_int), 4);
            make_graph(cpyCls5, learn, saver_file_stub, String.valueOf(outcome_int), 5);
            make_graph(cpyCls6, learn, saver_file_stub, String.valueOf(outcome_int), 6);
            make_graph(cpyCls7, learn, saver_file_stub, String.valueOf(outcome_int), 7);

        }

        } catch (Exception x) { System.out.println(x.toString());}










//        System.out.println("Cool");

    }

    private static void make_graph (BayesNet net, Instances data, String stub, String leave,int num) throws Exception{
        net.buildClassifier(data);
        String g1 = net.toString();
        String g1_out = stub.concat(leave).concat("_").concat(String.valueOf(num)).concat(".txt");
        writeLineToFile(g1, g1_out);
    }

    public static String getExtension(String s) {

        String ext = null;
        int i = s.lastIndexOf('.');

        if (i > 0 && i < s.length() - 1) {
            ext = s.substring(i + 1).toLowerCase();
        }
        return ext;
    }


    private static void appendLineToFile (String lineToWrite, String fileName) throws Exception{

            BufferedWriter out = new BufferedWriter(new FileWriter(fileName,true));
            out.append(lineToWrite);
            out.close();

    }
    private static void writeLineToFile (String lineToWrite, String fileName) throws Exception{

            File file = new File(fileName);
            file.createNewFile();

            BufferedWriter out = new BufferedWriter(new FileWriter(fileName,false));
            out.write(lineToWrite);
            out.close();

    }


}




            ///////// Creates the two new files
//            String small_fileName = fileName.substring(0,1+ fileName.lastIndexOf("\\")).concat("hold_out_").concat(fileName.substring(1+fileName.lastIndexOf("\\"), fileName.length()));
//            String big_fileName = fileName.substring(0, 1+fileName.lastInxdexOf("\\")).concat("learn_").concat(fileName.substring(1+fileName.lastIndexOf("\\"), fileName.length()));

//        Discretize disc = new Discretize();
//        disc.setAttributeIndices("16002");
//        try {
//            disc.setInputFormat(learn);
//            learn = disc.useFilter(learn, disc);
//            hold = disc.useFilter(hold, disc);
//        } catch (Exception ex) {
//            System.out.println(ex.toString());
//        }
//        System.out.println("4");

